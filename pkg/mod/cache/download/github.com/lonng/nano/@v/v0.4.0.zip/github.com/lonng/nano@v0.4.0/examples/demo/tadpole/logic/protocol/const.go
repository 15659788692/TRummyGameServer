package protocol

// Login status
const (
	LoginStatusSucc = 1
	LoginStatusFail = 2
)
