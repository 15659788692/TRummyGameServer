# starx-chat-demo
chat room demo base on [nano](https://github.com/lonnng/nano) in 100 lines

refs: https://github.com/lonnng/nano

## Required
- golang
- websocket

## Run
```
go run main.go
```

open browser => http://localhost:3250/web/