package protocol

// None represents a message with nothing
type None struct{}

// EmptyMessage was a shared empty message
var EmptyMessage = None{}
