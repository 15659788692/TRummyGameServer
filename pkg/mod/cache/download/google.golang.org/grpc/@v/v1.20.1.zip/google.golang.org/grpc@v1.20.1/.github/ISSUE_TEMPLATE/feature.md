---
name: Feature Request
about: Suggest an idea for gRPC-Go
labels: 'Type: Feature'

---

### Use case(s) - what problem will this feature solve?

### Proposed Solution

### Alternatives Considered

### Additional Context
