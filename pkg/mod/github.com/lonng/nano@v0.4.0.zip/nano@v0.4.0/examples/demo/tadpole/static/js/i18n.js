window.i18n = {
    QRCODE_LOADING: "正在加载二维码",
    SCANNING_QRCODE: "请扫描二维码选择游戏",
    DISCONNECT: "服务器断开",
    PLAYER_CONNECTED: "已有终端连入, 请选择游戏",
    MONITOR_NOT_FOUND: "未找到显示器"
};