# Tadpole

Online chat demo, ref: http://rumpetroll.com/

## Run demo
```shell
cd $GOPATH/src/github.com/lonnng/nano/examples/demo/tadpole
go run main.go
```

Open browser: http://127.0.0.1:23456/static/