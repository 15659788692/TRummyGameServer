var Settings = function () {
    this.host = window.location.hostname;
    this.port = 23456;
};
