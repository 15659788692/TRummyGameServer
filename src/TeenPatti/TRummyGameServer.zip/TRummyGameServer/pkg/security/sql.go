package security

// TODO: 验证SQL语句是否合法
func ValidateSQL(sql string) bool {
	return true
}
