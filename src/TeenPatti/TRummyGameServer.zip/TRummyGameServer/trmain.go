package main

import (
	"TeenPatti/TRummyGameServer/internal/game"
)

func main() {




 	game.Startup()



}
