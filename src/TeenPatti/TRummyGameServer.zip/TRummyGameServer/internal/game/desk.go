package game

import (
	"TeenPatti/TRummyGameServer/Poker"
	"TeenPatti/TRummyGameServer/pkg/errutil"
	"fmt"

	// "fmt"
	"math/rand"
	"sync"
	"sync/atomic"
	"time"

	"github.com/lonng/nano"
	"github.com/lonng/nano/session"
	"github.com/pborman/uuid"
	log "github.com/sirupsen/logrus"

	"TeenPatti/TRummyGameServer/pkg/constant"
	"TeenPatti/TRummyGameServer/pkg/room"
	"TeenPatti/TRummyGameServer/protocol"
)

const (
	deskFullplayerNum = 5  //总的玩家数量
	deskMinplayerNum  = 2  //游戏开始的最小人数
	deskMaxLosePoint  = 80 //最多输80点
)

const ( //游戏状态
	gameState_WaitJoin  = 0
	gameState_WaitStart = 1
	gameState_SendCard  = 2
	gameState_Play      = 3 //玩家操作阶段
	gameState_Stettle   = 4
)
const ( //状态时间
	gameState_WaitStart_Time = 7  //游戏开始倒计时
	gameState_SendCard_Time  = 4  //发牌
	gameState_Play_Time      = 15 //每个玩家操作时间
	gameState_Stettle_Time   = 10 //结算时间
)

type DeskOpts struct {
	bootAmout   int //低注,进入此桌最少的投注额
	maxBlinds   int //最大盲注,最多可盖牌的圈数
	chaalLimit  int //单注限额
	potLimit    int //单局总投注额度
	betKeepTime int //总的投注时间,秒数

	//

}

type Desk struct {
	roomNo  room.Number //房间号
	deskID  int64       //desk表的pk
	deskOpt DeskOpts    //此桌的参数
	//	opts      *protocol.DeskOptions // 房间选项
	state     constant.DeskStatus // 状态
	round     uint32              // 第n局
	creator   int64               // 创建玩家UID
	createdAt int64               // 创建时间

	playMutex       sync.RWMutex
	players         []*Player       //房间内所有玩家
	seatPlayers     map[int]*Player //座位上的玩家
	doingPlayers    map[int]*Player //正在玩的玩家
	group           *nano.Group     //房间内组播通道
	InDeskPlayGroup *nano.Group     //正在玩的玩家广播通道
	isFirstRound    bool            //是否是本桌的第一局牌
	totalBet        int64           //总投注
	logger          *log.Entry

	//游戏部分
	CardMgr       GMgrCard //卡牌管理器
	gameState     int      //游戏状态
	gameStateTime int32    //状态时间
	TList         []*Timer // 定时器列表

	Banker        *Player //庄家
	FristOuter    *Player //首出玩家
	WildCard      GCard   //万能牌(除大小王外的另一张万能牌)
	PublicCard    []GCard //公摊牌堆
	OperatePlayer *Player //当前正在操作的玩家
	PointValue    int64   //底注
	SettleCoins   int64
}

func NewDesk(roomNo room.Number, opts DeskOpts) *Desk {

	d := &Desk{

		state: constant.DeskStatusCreate,

		roomNo:  roomNo,
		deskOpt: opts,

		players:         []*Player{},
		seatPlayers:     map[int]*Player{},
		doingPlayers:    map[int]*Player{},
		group:           nano.NewGroup(uuid.New()),
		InDeskPlayGroup: nano.NewGroup(uuid.New()),

		isFirstRound: true,

		logger: log.WithField("deskno", roomNo),
	}
	//获取随机种子
	rand.Seed(time.Now().UnixNano())
	d.CardMgr.InitCards()
	d.CardMgr.Shuffle()
	go d.DoTimer()

	logger.Println("new desk:", roomNo.String())

	return d
}

// 玩家数量
func (d *Desk) totalPlayerCount() int {

	d.playMutex.Lock()
	defer d.playMutex.Unlock()

	return len(d.players)

}

//获取座位上玩家是否满了
func (this *Desk) GetSeatIsFull() bool {
	this.playMutex.Lock()
	defer this.playMutex.Unlock()
	return len(this.seatPlayers) >= deskFullplayerNum
}

//检测桌子人数是否满了
func (d *Desk) IsFullPlayer() bool {

	d.playMutex.Lock()
	defer d.playMutex.Unlock()

	if len(d.players) == deskFullplayerNum {
		return true
	}

	return false
}

// 如果是重新进入 isReJoin: true
func (d *Desk) playerJoin(s *session.Session, isReJoin bool) error {

	uid := s.UID()

	var (
		p   *Player
		err error
	)

	if isReJoin {
		//d.dissolve.updateOnlineStatus(uid, true)
		p, err = d.playerWithId(uid)
		if err != nil {
			d.logger.Errorf("玩家: %d重新加入房间, 但是没有找到玩家在房间中的数据", uid)
			return err
		}
		// 加入分组
		d.group.Add(s)

	} else {
		exists := false

		for _, p := range d.players {

			if p.Uid() == uid {
				exists = true
				p.logger.Warn("玩家已经在房间中")
				break
			}
		}

		if !exists {
			p = s.Value(kCurPlayer).(*Player)
			if !d.AddPlayerToDesk(p) {
				d.logger.Error("desk.playerJoin的玩家为空指针", p)
			}
			//d.roundStats[uid] = &history.Record{}
		}
	}
	return nil
}

//发送桌上玩家的状态信息给 每个人
func (d *Desk) PlayerJoinAfterInfo(p *Player, s *session.Session) error {

	// d.playMutex.Lock()
	// defer d.playMutex.Unlock()
	//广播玩家加入信息
	d.group.Broadcast(NoticePlayerJoin, &protocol.EnterDeskInfo{
		SeatPos:  p.seatPos,
		Nickname: p.name,
		Sex:      p.sex,
		HeadUrl:  p.head,
		Score:    p.betScore,
		StarNum:  p.starNum,
		IsBanker: p.isBanker,
		Sitdown:  p.sitdown,
		Betting:  false, /*p.IsBetting()*/
		Packed:   p.packed,
		Show:     p.showed,
		Blind:    p.blinded,
	})
	//给玩家发送桌子信息
	d.group.Add(p.session)

	deskInfo := protocol.DeskInfo{
		PointValue:    d.PointValue,
		DecksNum:      2,
		MaxWining:     deskFullplayerNum * d.PointValue * deskMaxLosePoint,
		Maxlosing:     d.PointValue * deskMaxLosePoint,
		SettleCoins:   d.SettleCoins,
		GameState:     int32(d.gameState),
		GameStateTime: int32(d.GetTimerNum(d.gameState)),
		OperSeatId:    int32(d.OperatePlayer.seatPos),
		BankerSeatId:  int32(d.Banker.seatPos),
		FirstSeatId:   int32(d.FristOuter.seatPos),
	}

	for _, p := range d.seatPlayers {

		deskInfo.PlayersInfo = append(deskInfo.PlayersInfo, protocol.EnterDeskInfo{
			SeatPos:  p.seatPos,
			Nickname: p.name,
			Sex:      p.sex,
			HeadUrl:  p.head,
			Score:    p.betScore,
			StarNum:  p.starNum,
			IsBanker: p.isBanker,
			Sitdown:  p.sitdown,
			Betting:  false,
			Packed:   p.packed,
			Show:     p.showed,
			Blind:    p.blinded,
		})
	}
	fmt.Println("p.session", p.session)
	err := s.Response(&protocol.JoinDeskResponse{
		Success:  true,
		DeskInfo: deskInfo,
	})
	d.logger.Println("BroadDeskPlayersInfo ")

	if d.gameState != gameState_WaitStart {
		return err
	}
	d.ClearTimer()
	d.AddTimer(gameState_WaitStart, gameState_WaitStart_Time, d.start, nil)
	d.group.Broadcast(NoticeGameState, &protocol.GGameStateNotice{
		GameState: int32(d.gameState),
		Time:      int32(d.GetTimerNum(d.gameState)),
	})

	return err

}

func (this *Desk) start(z interface{}) {

	//检测桌子开始条件是否符合
	if len(this.players) < deskMinplayerNum {
		if len(this.players) == 0 {
			//解散桌子
		}
		this.gameState = gameState_WaitJoin
		return
	}
	//游戏开始
	this.ClearTimer()
	this.gameState = gameState_SendCard
	this.doingPlayers = this.seatPlayers
	//洗牌
	this.CardMgr.Shuffle()
	//发牌
	for _, p := range this.players {
		p.HandCards = append([]GCard{}, this.CardMgr.SendCard(13)...)
	}
	//定庄(有庄不变，没庄换庄)
	if this.Banker == nil {
		this.Banker = this.players[rand.Intn(len(this.players))]
		//定首家(庄家的下家)
		this.OperatePlayer = this.players[(this.Banker.seatPos+1)%deskFullplayerNum]
	} else {
		//定首家(庄家的下家)
		for i := 1; i < deskFullplayerNum; i++ {
			bankernext := this.seatPlayers[(this.Banker.seatPos+i)%deskFullplayerNum]
			if bankernext != nil {
				this.OperatePlayer = bankernext
				break
			}
		}
	}
	//广播开始通知
	this.group.Broadcast(NoticeGameStrat, &protocol.GGameStartNotice{
		BankerId: int32(this.Banker.seatPos),
		FristID:  int32(this.OperatePlayer.seatPos),
	})

	//定万能牌
	this.WildCard = this.CardMgr.SendCard(1)[0]
	//翻第一张牌
	this.PublicCard = this.CardMgr.SendCard(1)
	for _, p := range this.seatPlayers {
		handcard := []int32{}
		for _, v := range p.HandCards {
			handcard = append(handcard, int32(v.Card))
		}
		p.session.Response(&protocol.GSendCardNotice{
			HandCards: handcard,
			WildCard:  this.WildCard.Card,
			FristCard: this.PublicCard[len(this.PublicCard)-1].Card,
		})
	}
	//出牌阶段
	this.AddTimer(gameState_SendCard, gameState_SendCard_Time, this.SendCard_OutTime, nil)

}

//玩家操作通知
func (this *Desk) SendCard_OutTime(interface{}) {
	this.OperatePlayer.session.Response(&protocol.GGameStateNotice{
		GameState: int32(this.gameState),
		Time:      int32(this.GetTimerNum(this.gameState)),
	})
	this.gameState = gameState_Play
	this.AddTimer(gameState_Play, gameState_Play_Time, this.PlayerOper_OutTime, nil)
}

//玩家操作超时
func (this *Desk) PlayerOper_OutTime(interface{}) {
	handcard := this.OperatePlayer.HandCards
	if len(handcard) < 13 || len(handcard) > 14 {
		this.logger.Error("player:%s  手牌数不对，手牌是%v", this.OperatePlayer.name, handcard)
	}
	if len(handcard) == 13 {
		//摸牌操作
		this.OperCard(this.OperatePlayer, &protocol.GOperCardRequest{Opertion: 1})
	}
	//出牌操作
	this.OperCard(this.OperatePlayer, &protocol.GOperCardRequest{
		Opertion: 3,
		OperCard: this.OperatePlayer.HandCards[len(this.OperatePlayer.HandCards)-1].Card,
	})
}

//操作牌
func (this *Desk) OperCard(p *Player, msg *protocol.GOperCardRequest) (err error) {
	//游戏状态监测
	if this.gameState != gameState_Play {
		return p.session.Response(&protocol.GOperCardResponse{
			Opertion: 0,
			Error:    "玩家不在游戏中！",
		})
	}
	//检测是否轮到该玩家
	if this.OperatePlayer != p {
		return p.session.Response(&protocol.GOperCardResponse{
			Opertion: 0,
			Error:    "还未轮到该玩家操作！",
		})
	}
	//检测是否摸牌
	if len(p.HandCards) != 13 && len(p.HandCards) != 14 {
		this.logger.Debug("玩家%s手牌数%s不对!  ", p.name, len(p.HandCards), p.uid)
		return p.session.Response(&protocol.GOperCardResponse{
			Opertion: 0,
			Error:    "玩家手牌数不对！",
		})
	}
	//判断玩家的操作
	//摸牌公摊牌
	if msg.Opertion == 1 && len(p.HandCards) == 13 {
		p.HandCards = append(p.HandCards, this.PublicCard[len(this.PublicCard)-1])
		this.PublicCard = append([]GCard{}, this.PublicCard[:len(this.PublicCard)-1]...)
		err = p.session.Response(&protocol.GOperCardResponse{
			Opertion:   msg.Opertion,
			OperCard:   msg.OperCard,
			PublicCard: this.PublicCard[len(this.PublicCard)-1].Card,
		})
		this.group.Broadcast(NoticeGameOperCard, &protocol.GPlayerOperNotice{
			SeatId:     int32(p.seatPos),
			Opertion:   msg.Opertion,
			OperCard:   msg.OperCard,
			PublicCard: this.PublicCard[len(this.PublicCard)-1].Card,
		})
		return
	}
	//摸牌堆的牌
	if msg.OperCard == 2 && len(p.HandCards) == 13 {
		p.HandCards = append(p.HandCards, this.CardMgr.SendCard(1)...)
		//应答
		err = p.session.Response(&protocol.GOperCardResponse{
			Opertion:   msg.Opertion,
			OperCard:   msg.OperCard,
			PublicCard: this.PublicCard[len(this.PublicCard)-1].Card,
		})
		//广播
		this.group.Broadcast(NoticeGameOperCard, &protocol.GPlayerOperNotice{
			SeatId:     int32(p.seatPos),
			Opertion:   msg.Opertion,
			PublicCard: this.PublicCard[len(this.PublicCard)-1].Card,
		})
		return
	}
	//出牌
	if msg.Opertion == 3 && len(p.HandCards) == 14 {
		this.DelTimer(gameState_Play)
		if !p.DelHandCard(msg.OperCard) {
			p.session.Response(&protocol.GOperCardResponse{
				Opertion: 0,
				Error:    "玩家操作错误！没有这张手牌！",
			})
		}
		this.PublicCard = append(this.PublicCard, GCard{Poker.CardBase{Card: msg.OperCard}})
		//请求回复
		err := p.session.Response(&protocol.GOperCardResponse{
			Opertion:   msg.Opertion,
			OperCard:   msg.OperCard,
			PublicCard: this.PublicCard[len(this.PublicCard)-1].Card,
		})
		//广播
		this.group.Broadcast(NoticeGameOperCard, &protocol.GPlayerOperNotice{
			SeatId:     int32(p.seatPos),
			Opertion:   msg.Opertion,
			OperCard:   msg.OperCard,
			PublicCard: this.PublicCard[len(this.PublicCard)-1].Card,
		})

		//轮到下一位玩家
		for i := 1; i < deskFullplayerNum; i++ {
			nextplayer := this.seatPlayers[(this.OperatePlayer.seatPos+i)%deskFullplayerNum]
			if nextplayer != nil {
				this.OperatePlayer = nextplayer
				break
			}
		}
		this.SendCard_OutTime(nil)
		return err
	}
	//show（胡了）
	if msg.Opertion == 4 && len(p.HandCards) == 14 {
		this.DelTimer(gameState_Play)
		//结算
		return
	}

	return p.session.Response(&protocol.GOperCardResponse{
		Opertion: 0,
		Error:    "玩家操作错误！",
	})
}

func (d *Desk) status() constant.DeskStatus {
	return constant.DeskStatus(atomic.LoadInt32((*int32)(&d.state)))
}

//检测桌子的玩家是否可以结算了
func (d *Desk) deskIsAccount() bool {

	return false

}

func (d *Desk) playerWithId(uid int64) (*Player, error) {

	for _, p := range d.players {
		if p.Uid() == uid {
			return p, nil
		}
	}

	return nil, errutil.ErrPlayerNotFound
}

//玩家是否为空了
func (d *Desk) PlayersIsEmpty() bool {

	bempty := false

	if d.totalPlayerCount() == 0 {

		bempty = true
	}

	return bempty
}

// 摧毁桌子
func (d *Desk) destroy() {

	//删除桌子
	//scheduler.PushTask(func() {
	//	defaultDeskManager.setDesk(d.roomNo, nil)
	//})

}

func (d *Desk) onPlayerExit(s *session.Session, isDisconnect bool) {

	d.logger.Println("玩家下线了：uid", s.UID())

	uid := s.UID()
	d.group.Leave(s)

	if isDisconnect {
		//	d.dissolve.updateOnlineStatus(uid, false)
	} else {

		restPlayers := []*Player{}

		for _, p := range d.players {

			if p.Uid() != uid {
				restPlayers = append(restPlayers, p)
			} else {
				//p.reset()
				p.desk = nil
				//p.score = 1000
				//p.turn = 0
			}
		}
		d.players = restPlayers
	}

	/*//如果桌上已无玩家, destroy it
	if d.creator == uid && !isDisconnect {
		//if d.dissolve.offlineCount() == len(d.players) || (d.creator == uid && !isDisconnect) {
		d.logger.Info("所有玩家下线或房主主动解散房间")
		if d.dissolve.isDissolving() {
			d.dissolve.stop()
		}
		d.destroy()

		// 数据库异步更新
		async.Run(func() {
			desk := &model.Desk{
				Id:    d.deskID,
				Round: 0,
			}
			if err := db.UpdateDesk(desk); err != nil {
				log.Error(err)
			}
		})
	}

	*/

}

//获取游戏状态
func (this *Desk) GetGameState() int {
	return this.gameState
}

//设置游戏状态
func (this *Desk) SetGameState(gamestate int) bool {
	//状态不变
	if gamestate == this.gameState {
		return false
	}
	this.gameState = gamestate
	return true
}

//添加玩家到桌子里
func (this *Desk) AddPlayerToDesk(p *Player) bool {
	if p == nil {
		return false
	}
	this.players = append(this.players, p)
	//设置座位号
	for i := 0; i < deskFullplayerNum; i++ {
		if this.seatPlayers[i] == nil {
			this.seatPlayers[i] = p
			p.SetSeatPos(i)
			break
		}
		//不在座位上设为-1
		p.SetSeatPos(-1)
	}
	for i, p := range this.players {
		p.setDesk(this, i)
	}
	//如果玩家玩家人数够了
	if len(this.seatPlayers) >= 2 && this.gameState == gameState_WaitJoin {
		this.gameState = gameState_WaitStart
	}
	return true
}
