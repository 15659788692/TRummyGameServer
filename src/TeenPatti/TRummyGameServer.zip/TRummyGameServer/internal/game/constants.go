package game


const (
	kCurPlayer = "player"
)

